package �Թ�����;

public class Point {
	int x, y, d;

	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public Point(int x, int y, int d) {
		this.x = x;// x
		this.y = y;// y
		this.d = d;// d
	}
}
